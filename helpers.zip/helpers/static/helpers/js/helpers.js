(function () {
  const root = document.documentElement;
  const key = 'mk-theme';
  const toggles = document.querySelectorAll('[data-theme-toggle]');

  function currentTheme() {
    const stored = localStorage.getItem(key);
    if (stored === 'dark' || stored === 'light') return stored;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function setTheme(theme) {
    const dark = theme === 'dark';
    root.classList.toggle('dark', dark);
    toggles.forEach(function (toggle) {
      toggle.textContent = dark ? '?' : '?';
      toggle.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
    });
  }

  setTheme(currentTheme());

  toggles.forEach(function (toggle) {
    toggle.addEventListener('click', function () {
      const next = root.classList.contains('dark') ? 'light' : 'dark';
      localStorage.setItem(key, next);
      setTheme(next);
    });
  });
})();
