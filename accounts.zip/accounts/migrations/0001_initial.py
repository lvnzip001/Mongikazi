# Generated for MongiKazi accounts app.

import django.contrib.auth.models
import django.contrib.auth.validators
import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("auth", "0012_alter_user_first_name_max_length"),
    ]

    operations = [
        migrations.CreateModel(
            name="User",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("password", models.CharField(max_length=128, verbose_name="password")),
                ("last_login", models.DateTimeField(blank=True, null=True, verbose_name="last login")),
                ("is_superuser", models.BooleanField(default=False, help_text="Designates that this user has all permissions without explicitly assigning them.", verbose_name="superuser status")),
                ("username", models.CharField(error_messages={"unique": "A user with that username already exists."}, help_text="Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.", max_length=150, unique=True, validators=[django.contrib.auth.validators.UnicodeUsernameValidator()], verbose_name="username")),
                ("first_name", models.CharField(blank=True, max_length=150, verbose_name="first name")),
                ("last_name", models.CharField(blank=True, max_length=150, verbose_name="last name")),
                ("email", models.EmailField(max_length=254, unique=True, verbose_name="email address")),
                ("is_staff", models.BooleanField(default=False, help_text="Designates whether the user can log into this admin site.", verbose_name="staff status")),
                ("is_active", models.BooleanField(default=True, help_text="Designates whether this user should be treated as active. Unselect this instead of deleting accounts.", verbose_name="active")),
                ("date_joined", models.DateTimeField(default=django.utils.timezone.now, verbose_name="date joined")),
                ("role", models.CharField(blank=True, choices=[("EMPLOYER", "Employer"), ("HELPER", "Helper"), ("OPERATIONS", "Operations"), ("ADMIN", "Admin")], max_length=20)),
                ("phone_number", models.CharField(blank=True, max_length=20, null=True, unique=True)),
                ("is_phone_verified", models.BooleanField(default=False)),
                ("is_onboarding_complete", models.BooleanField(default=False)),
                ("accepted_terms", models.BooleanField(default=False)),
                ("accepted_terms_at", models.DateTimeField(blank=True, null=True)),
                ("groups", models.ManyToManyField(blank=True, help_text="The groups this user belongs to. A user will get all permissions granted to each of their groups.", related_name="mongikazi_user_set", related_query_name="mongikazi_user", to="auth.group", verbose_name="groups")),
                ("user_permissions", models.ManyToManyField(blank=True, help_text="Specific permissions for this user.", related_name="mongikazi_user_set", related_query_name="mongikazi_user", to="auth.permission", verbose_name="user permissions")),
            ],
            options={
                "verbose_name": "user",
                "verbose_name_plural": "users",
                "abstract": False,
            },
            managers=[
                ("objects", django.contrib.auth.models.UserManager()),
            ],
        ),
        migrations.AddIndex(model_name="user", index=models.Index(fields=["role"], name="accounts_us_role_91c18a_idx")),
        migrations.AddIndex(model_name="user", index=models.Index(fields=["phone_number"], name="accounts_us_phone_n_21d2e7_idx")),
        migrations.AddIndex(model_name="user", index=models.Index(fields=["is_onboarding_complete"], name="accounts_us_is_onbo_4c8be8_idx")),
    ]
