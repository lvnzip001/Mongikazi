from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods

from .forms import MongiKaziLoginForm, RegisterForm
from .models import User
from .services.redirect_service import get_onboarding_url, get_role_redirect_url
from .services.registration_service import complete_registration


@require_http_methods(["GET"])
def role_select(request):
    if request.user.is_authenticated:
        return redirect(get_role_redirect_url(request.user))
    return render(request, "accounts/role_select.html")


@require_http_methods(["GET", "POST"])
def register(request, role):
    role = role.upper()
    valid_roles = {User.Role.EMPLOYER, User.Role.HELPER}
    if role not in valid_roles:
        messages.warning(request, "Please choose whether you need help or want work.")
        return redirect("accounts:role_select")

    if request.user.is_authenticated:
        return redirect(get_role_redirect_url(request.user))

    form = RegisterForm(request.POST or None, role=role)
    if request.method == "POST" and form.is_valid():
        _, next_url = complete_registration(request, form)
        return redirect(next_url)

    context = {
        "form": form,
        "role": role,
        "is_employer": role == User.Role.EMPLOYER,
        "page_title": "Create your employer account" if role == User.Role.EMPLOYER else "Create your helper profile",
    }
    return render(request, "accounts/register.html", context)


@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.user.is_authenticated:
        return redirect(get_role_redirect_url(request.user))

    form = MongiKaziLoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect(get_role_redirect_url(form.get_user()))

    return render(request, "accounts/login.html", {"form": form})


@login_required
def account_pending(request):
    return render(
        request,
        "accounts/account_pending.html",
        {
            "next_url": get_onboarding_url(request.user),
            "portal_url": get_role_redirect_url(request.user),
            "is_employer": getattr(request.user, "is_employer", False),
            "is_helper": getattr(request.user, "is_helper", False),
        },
    )


@require_http_methods(["POST", "GET"])
def logout_view(request):
    logout(request)
    return redirect(reverse("website:home"))
