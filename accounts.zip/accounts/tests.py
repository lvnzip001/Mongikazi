from django.test import TestCase, override_settings
from django.urls import reverse

from .models import User
from .services.redirect_service import get_onboarding_url, get_role_redirect_url


@override_settings(ROOT_URLCONF="accounts.urls")
class AccountsModelTests(TestCase):
    def test_user_role_helpers(self):
        user = User.objects.create_user(
            username="helper@example.com",
            email="helper@example.com",
            password="safe-password-123",
            role=User.Role.HELPER,
            phone_number="0710000001",
        )
        self.assertTrue(user.is_helper)
        self.assertFalse(user.is_employer)

    def test_permission_related_names_do_not_use_default_user_set(self):
        groups_field = User._meta.get_field("groups")
        permissions_field = User._meta.get_field("user_permissions")
        self.assertEqual(groups_field.remote_field.related_name, "mongikazi_user_set")
        self.assertEqual(permissions_field.remote_field.related_name, "mongikazi_user_set")


class RedirectServiceTests(TestCase):
    def test_incomplete_employer_goes_to_pending_page(self):
        user = User(username="employer@example.com", role=User.Role.EMPLOYER, is_onboarding_complete=False)
        self.assertEqual(get_role_redirect_url(user), reverse("accounts:account_pending"))
        self.assertEqual(get_onboarding_url(user), "/employer/onboarding/")
