document.addEventListener("DOMContentLoaded", function () {
  const openButton = document.querySelector("[data-mobile-menu-open]");
  const closeButton = document.querySelector("[data-mobile-menu-close]");
  const menu = document.querySelector("[data-mobile-menu]");

  if (!openButton || !closeButton || !menu) {
    return;
  }

  function openMenu() {
    menu.classList.remove("hidden");
    document.body.classList.add("overflow-hidden");
  }

  function closeMenu() {
    menu.classList.add("hidden");
    document.body.classList.remove("overflow-hidden");
  }

  openButton.addEventListener("click", openMenu);
  closeButton.addEventListener("click", closeMenu);

  menu.addEventListener("click", function (event) {
    if (event.target === menu) {
      closeMenu();
    }
  });
});
