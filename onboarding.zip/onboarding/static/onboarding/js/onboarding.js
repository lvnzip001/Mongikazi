(function () {
  const root = document.documentElement;
  const progressBars = document.querySelectorAll('[data-progress-bar]');

  progressBars.forEach(function (bar) {
    const value = Number(bar.getAttribute('data-progress-value') || 0);
    bar.style.width = Math.max(0, Math.min(100, value)) + '%';
  });

  if (!localStorage.getItem('mk-theme')) {
    root.classList.remove('dark');
  }
})();
